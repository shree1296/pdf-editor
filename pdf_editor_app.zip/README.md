# PDF Editor with Font Detection and Image Replacement

## Features
- Detect fonts (family + size) in PDF
- Replace selected text while preserving font/size where possible
- Replace embedded images
- Save edited PDF

## How to Get the .exe
1. Push this repo to your own GitHub (to the `main` branch).
2. Go to **Actions** tab → Select **Build PDF Editor EXE** → Click **Run workflow**.
3. After it runs, download `PDFEditor.exe` from the workflow **Artifacts** section.

## Local Development
```bash
pip install -r requirements.txt
python main.py
```

## Notes & Limitations
- Text replacement is done via redaction + text insert. PDFs do not reflow like word processors; long replacements may overlap or require font size adjustments.
- Font names reported are those in the PDF's text spans; if the PDF doesn't embed a font, the replacement uses a fallback font.
- Image replacement targets the first image found on the page in this MVP. You can extend the UI to choose among images.
