# main.py
import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QFileDialog, QPushButton, QLabel, QListWidget, QVBoxLayout, QWidget, QInputDialog, QMessageBox
)
from pdf_manager import PDFManager

class PDFEditor(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PDF Editor with Font & Image Replacement")
        self.setGeometry(200, 200, 800, 600)

        self.pdf_manager = None
        self.current_page = 0

        layout = QVBoxLayout()

        self.open_btn = QPushButton("Open PDF")
        self.open_btn.clicked.connect(self.open_pdf)
        layout.addWidget(self.open_btn)

        layout.addWidget(QLabel("Fonts & Text (page 0):"))
        self.font_list = QListWidget()
        layout.addWidget(self.font_list)

        self.replace_text_btn = QPushButton("Replace Selected Text")
        self.replace_text_btn.clicked.connect(self.replace_selected_text)
        layout.addWidget(self.replace_text_btn)

        self.replace_img_btn = QPushButton("Replace First Image on Page")
        self.replace_img_btn.clicked.connect(self.replace_image)
        layout.addWidget(self.replace_img_btn)

        self.save_btn = QPushButton("Save PDF As...")
        self.save_btn.clicked.connect(self.save_pdf)
        layout.addWidget(self.save_btn)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

    def open_pdf(self):
        filepath, _ = QFileDialog.getOpenFileName(self, "Open PDF", "", "PDF Files (*.pdf)")
        if filepath:
            try:
                self.pdf_manager = PDFManager(filepath)
                self.load_fonts()
                QMessageBox.information(self, "Loaded", f"Loaded PDF: {filepath}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to open PDF: {e}")

    def load_fonts(self):
        if not self.pdf_manager:
            return
        self.font_list.clear()
        try:
            fonts = self.pdf_manager.list_fonts_and_text(self.current_page)
            for item in fonts:
                display = item['text'].replace('\n', ' ')[:200]
                self.font_list.addItem(f"{display} | {item['font']} | {item['size']}pt")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to extract text spans: {e}")

    def replace_selected_text(self):
        if not self.pdf_manager:
            return
        selected = self.font_list.currentItem()
        if not selected:
            QMessageBox.information(self, "Select", "Please select a text span from the list.")
            return
        old_text = selected.text().split(" | ")[0]
        new_text, ok = QInputDialog.getText(self, "Replace Text", f"Replace '{old_text}' with:")
        if ok and new_text:
            try:
                # naive replace on the current page
                self.pdf_manager.replace_text(self.current_page, old_text, new_text)
                self.load_fonts()
                QMessageBox.information(self, "Done", "Text replaced. Save the file to persist changes.")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to replace text: {e}")

    def replace_image(self):
        if not self.pdf_manager:
            return
        try:
            images = self.pdf_manager.list_images(self.current_page)
            if not images:
                QMessageBox.information(self, "No images", "No images found on this page.")
                return
            xref = images[0]['xref']
            new_img, _ = QFileDialog.getOpenFileName(self, "Select New Image", "", "Images (*.png *.jpg *.jpeg)")
            if new_img:
                self.pdf_manager.replace_image(xref, new_img)
                QMessageBox.information(self, "Done", "Image replaced. Save the file to persist changes.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to replace image: {e}")

    def save_pdf(self):
        if not self.pdf_manager:
            return
        filepath, _ = QFileDialog.getSaveFileName(self, "Save PDF", "edited.pdf", "PDF Files (*.pdf)")
        if filepath:
            try:
                self.pdf_manager.save(filepath)
                QMessageBox.information(self, "Saved", f"Saved edited PDF to: {filepath}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to save PDF: {e}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = PDFEditor()
    window.show()
    sys.exit(app.exec_())
