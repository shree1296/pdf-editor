# pdf_manager.py
import fitz  # PyMuPDF
from PIL import Image
import io

class PDFManager:
    def __init__(self, filepath):
        self.filepath = filepath
        self.doc = fitz.open(filepath)

    def list_fonts_and_text(self, page_number):
        """
        Returns a list of dictionaries with text, font name, font size, and bbox for each span.
        """
        page = self.doc[page_number]
        text_info = []

        blocks = page.get_text("dict")["blocks"]
        for block in blocks:
            if "lines" in block:
                for line in block["lines"]:
                    for span in line["spans"]:
                        text_info.append({
                            "text": span["text"],
                            "font": span["font"],
                            "size": round(span["size"], 2),
                            "bbox": span["bbox"]
                        })
        return text_info

    def replace_text(self, page_number, old_text, new_text, fontsize=None, fontname=None, color=(0,0,0)):
        """
        Replace a given text string with new text on a page.
        This implementation redacts found areas and inserts new text at the top-left of each area.
        It attempts to preserve font size/name when provided.
        """
        page = self.doc[page_number]
        found_areas = page.search_for(old_text)
        for area in found_areas:
            # redact the original text (white fill)
            page.add_redact_annot(area, fill=(1, 1, 1))
        if found_areas:
            page.apply_redactions()
        for area in found_areas:
            insert_pos = (area.x0, area.y0)
            fs = fontsize or 12
            fn = fontname or "helv"  # PDF font name; fallback to helv
            page.insert_text(insert_pos, new_text, fontsize=fs, fontname=fn, fill=color)

    def list_images(self, page_number):
        """
        Returns a list of images with their xref and dimensions.
        """
        page = self.doc[page_number]
        images = page.get_images(full=True)
        img_list = []
        for img in images:
            xref = img[0]
            base_image = self.doc.extract_image(xref)
            img_list.append({
                "xref": xref,
                "width": base_image.get("width"),
                "height": base_image.get("height"),
                "ext": base_image.get("ext")
            })
        return img_list

    def replace_image(self, xref, new_image_path):
        """Replaces an image in the PDF by its xref number."""
        img = Image.open(new_image_path)
        img_byte_arr = io.BytesIO()
        # save as PNG bytes to ensure broad compatibility
        img.save(img_byte_arr, format="PNG")
        img_bytes = img_byte_arr.getvalue()
        # update_image expects a dictionary-like object in some PyMuPDF versions.
        try:
            # newer fitz versions offer update_image
            self.doc.update_image(xref, img_bytes)
        except Exception:
            # fallback approach: replace the xref object
            self.doc._updateStream(xref, img_bytes)

    def save(self, output_path):
        self.doc.save(output_path)
        self.doc.close()
